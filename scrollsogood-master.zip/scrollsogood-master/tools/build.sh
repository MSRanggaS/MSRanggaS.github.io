rm ssg.min.js
minify ssg.js >> ssg.min.js
open ./test/test.html